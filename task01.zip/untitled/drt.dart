

void main() {
  // for loop
  var num = 5;
  for (var i = num; i >= 1; i--) {
    print(i);
  }
  //for in loop
  var names = ["Nourhan", "Hanna", "Omar", "Rewan"];
  for (var name in names) {
    print(name);
  }
  while (num >= 1) {
    print(num);
    num--;
  }
  // Logic in dart
  // Iff
  var num5 = 3.1;
  if (num5 == 5) {
    print('the number is 5!');
  }
  // if this is true, it would get executed. Otherwise nothing will be executed.
  // that means in the case the code gets executed when only the variable is equal the input
  else if (num5 == 3.1) {
    print('The number is 3.1!');
  }
  else {
    print('The input is invalid');
  }
  // FUNCTIONS IN DART
  // String myFunc(){
  //   return "Hello functions";}
  //print(myFunc());
  //var thing = myFunc();
  //print(thing);


  // If else if to use an addional condition

   String myFunc2 ( name1,name2){
    return "Hello $name1 and $name2";

   }
  var thing2 = myFunc2("Nourhan", "Noura");

}


