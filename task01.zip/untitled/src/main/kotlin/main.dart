import 'dart:io';

void main() {
  stdout.writeln('Please enter your name: ');
  var name = stdin.readLineSync();
  print('Your name is $name');
  // remember the raw string

  // multi line string
  String n = """ nourhan is one of the 
      best for example """;
  print(n);

  // how to convert string to int
  var one = int.parse('1');
  assert(one == 1);
  print('The number is $one' '');

  // how to convert string to double
  var oneptone = double.parse('1.1');
  assert(oneptone == 1.1);
  print('The number is $oneptone');

  // how to convert int to string
  String oneasstring = 1.toString();
  assert(oneasstring == '1');
  print(oneasstring);

  // how to convert double into string
  String oneasdouble = 2.223.toStringAsFixed(2);
  assert(oneasdouble == '2.22');
  print(oneasdouble);

  // we can define a variable as a constant data
  const nour = ' Palestine';
  const a1 = 1;
  const isit = true;

  print(nour);
  print(a1);
  print(true);

  print(nour.runtimeType);
  print(a1.runtimeType);
  print(isit.runtimeType);

 }