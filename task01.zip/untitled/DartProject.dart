// A simple application for Dart called Fizzbuzz
void main(){
  int num = 1;
  while(num <=250) {
    if (num % 5 == 0 && num % 3 == 0) {
      print("$num. is FizzBuzz!");
    }
    else if (num % 3 == 0) {
      print("num. is Fizz!");
    }
    else if (num % 5 == 0) {
      print("$num. is Buzz!");
    }
    else {
      print("$num. bad");
    }
    num++;
  }



}






